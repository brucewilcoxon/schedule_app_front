import React from 'react';
import { Users, Shield, Calendar, TrendingUp } from 'lucide-react';
import StatsCard from './StatsCard';
import CalendarWidget from './CalendarWidget';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const Dashboard: React.FC = () => {
  const stats = [
    {
      title: 'Active Users',
      value: '2,847',
      change: '+12% from last month',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      title: 'Security Events',
      value: '156',
      change: '-8% from last week',
      icon: Shield,
      color: 'bg-red-500'
    },
    {
      title: 'Scheduled Tasks',
      value: '89',
      change: '+23% from yesterday',
      icon: Calendar,
      color: 'bg-green-500'
    },
    {
      title: 'Performance',
      value: '98.5%',
      change: '+0.3% uptime',
      icon: TrendingUp,
      color: 'bg-purple-500'
    }
  ];

  const recentActivity = [
    { id: '1', action: 'User login', user: 'john.doe@company.com', time: '2 min ago', status: 'success' },
    { id: '2', action: 'Permission updated', user: 'admin@company.com', time: '5 min ago', status: 'info' },
    { id: '3', action: 'Failed login attempt', user: 'unknown@domain.com', time: '8 min ago', status: 'warning' },
    { id: '4', action: 'Schedule created', user: 'manager@company.com', time: '15 min ago', status: 'success' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      case 'info': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Widget */}
        <div className="lg:col-span-2">
          <CalendarWidget />
        </div>

        {/* Recent Activity */}
        <Card className="shadow-lg border-0 bg-gradient-to-br from-white to-purple-50">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-800">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="p-3 rounded-lg bg-white shadow-sm border">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-medium text-gray-800">{activity.action}</span>
                  <Badge className={getStatusColor(activity.status)}>
                    {activity.status}
                  </Badge>
                </div>
                <div className="text-sm text-gray-600">
                  <div>{activity.user}</div>
                  <div className="text-xs text-gray-500">{activity.time}</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;