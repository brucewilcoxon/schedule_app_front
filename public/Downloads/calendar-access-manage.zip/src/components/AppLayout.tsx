import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Header from './Header';
import Sidebar from './Sidebar';
import Dashboard from './Dashboard';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();
  const [localSidebarOpen, setLocalSidebarOpen] = useState(false);

  const handleMenuClick = () => {
    if (isMobile) {
      setLocalSidebarOpen(!localSidebarOpen);
    } else {
      toggleSidebar();
    }
  };

  const handleSidebarClose = () => {
    setLocalSidebarOpen(false);
  };

  const showSidebar = isMobile ? localSidebarOpen : sidebarOpen;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-100">
      <Header onMenuClick={handleMenuClick} />
      
      <div className="flex">
        {/* Sidebar */}
        <div className={`${isMobile ? '' : (sidebarOpen ? 'w-64' : 'w-0')} transition-all duration-300`}>
          <Sidebar isOpen={showSidebar} onClose={handleSidebarClose} />
        </div>
        
        {/* Main Content */}
        <main className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Authorization & Schedule Dashboard</h1>
              <p className="text-gray-600">Manage your corporate security and scheduling in one place</p>
            </div>
            <Dashboard />
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;