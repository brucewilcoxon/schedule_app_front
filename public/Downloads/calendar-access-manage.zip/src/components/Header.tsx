import React from 'react';
import { Button } from '@/components/ui/button';
import { Calendar, Users, Shield, Menu } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-purple-700 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={onMenuClick}
              className="md:hidden text-white hover:bg-white/20"
            >
              <Menu className="h-6 w-6" />
            </Button>
            <div className="flex items-center space-x-2">
              <Shield className="h-8 w-8" />
              <h1 className="text-2xl font-bold">AuthSchedule</h1>
            </div>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Button variant="ghost" className="text-white hover:bg-white/20">
              <Calendar className="h-4 w-4 mr-2" />
              Calendar
            </Button>
            <Button variant="ghost" className="text-white hover:bg-white/20">
              <Users className="h-4 w-4 mr-2" />
              Team
            </Button>
            <Button variant="ghost" className="text-white hover:bg-white/20">
              <Shield className="h-4 w-4 mr-2" />
              Security
            </Button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;